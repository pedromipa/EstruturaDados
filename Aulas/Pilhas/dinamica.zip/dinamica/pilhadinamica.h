
#ifndef pilhaDinamica_h
#define pilhaDinamica_h

#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <time.h>

typedef struct {
    int chave;
} Objeto;

typedef struct NoPilha* PtrNoPilha;

// Implementa os nós da pilha
typedef struct NoPilha{
  Objeto obj;
  PtrNoPilha proximo;
} NoPilha;

typedef struct {
  PtrNoPilha topo;
  int tamanho;
} PilhaDinamica;

void iniciaPilha(PilhaDinamica *p);
bool estaVazia(PilhaDinamica *p);
void empilha(PilhaDinamica *p, Objeto *obj);
int desempilha(PilhaDinamica *p, Objeto *obj);
int tamanhoPilha(PilhaDinamica *p);
void topo(PilhaDinamica *p, Objeto *obj);
void imprimePilha(PilhaDinamica *p);

#endif /* pilhaDinamica_h */
